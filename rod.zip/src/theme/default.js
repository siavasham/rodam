export default {
    primaryBackground: '#fefefe',
    backgroundSet: '#fff',
    primaryColor: '#555',
    secondaryColor: '#999',
    tabbarBackground: '#333',
    tabbarColor: '#fff',
    iconColor: '#444',
    avatarBackground: '#ccc'
}