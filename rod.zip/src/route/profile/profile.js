import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';

export default function Profile() {
    return (
        <View style={{ flex: 1, backgroundColor: '#333' }}>

        </View>
    );
}
