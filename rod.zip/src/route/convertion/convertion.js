import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';

export default function Bookmark() {
    return (
        <View style={{ flex: 1, backgroundColor: '#fff' }}>

        </View>
    );
}
