export default {
    home: 'خانه',
    explorer: 'بگرد',
    bookmark: 'نشان شده ',
    convertion: 'گفت و گو',
    profile: 'پروفایل',

    popular: 'پر بازدید ترین ها',
    viewAll: 'مشاهده همه'
}